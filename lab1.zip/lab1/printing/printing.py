def print_examples():
   n = 2
   m = 4
   f = 42.7
   # place the print calls specified in the lab description below here


if __name__ == '__main__':
   print_examples()
